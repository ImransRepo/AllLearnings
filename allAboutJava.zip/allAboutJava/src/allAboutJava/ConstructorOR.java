package allAboutJava;

public class ConstructorOR {

	int i;
	
	public ConstructorOR(int i) {
		this.i = i;
	}
	
	public static void main(String[] args) {

		
		
	}

}

class Sub extends ConstructorOR{

	public Sub(int i) {
		super(i);
		
	
	}
	
	
	
}
