package allAboutJava;

public class DefaultNProtected {
	
	int num = 10;
	String str = "Imran";
	
	void defaultMethod() {
		System.out.println("Default Method");
	}
	
	protected void protectedMethod() {
		System.out.println("Protected Method");
	}

}
