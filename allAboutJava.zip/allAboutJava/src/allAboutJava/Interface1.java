package allAboutJava;

public interface Interface1 {

	
	void method1();
	
	static void method2() {
		
	}
	
	default void method3() {
		
	}
}
