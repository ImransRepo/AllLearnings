package allAboutJava;

public class Static {

	static int num=10;
	static String str = "Test";
	

	public static void main(String[] args) {
		
		System.out.println(num +" : "+  str);
		System.gc();

	}

}
