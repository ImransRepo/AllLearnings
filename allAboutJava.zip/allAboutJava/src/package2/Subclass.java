package package2;

import allAboutJava.DefaultNProtected;

public class Subclass extends DefaultNProtected{

	public static void main(String[] args) {

		Subclass dnp = new Subclass();
		dnp.protectedMethod();		
	
	}

}
