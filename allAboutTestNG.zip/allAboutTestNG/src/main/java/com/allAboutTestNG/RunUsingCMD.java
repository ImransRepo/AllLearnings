package com.allAboutTestNG;

import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class RunUsingCMD {
	
	@Ignore
	@Test
	public void test1()
	{
		System.out.println("Run Using Command Line");
	}
	
	
	@Test
	public void test2() {
		
		System.out.println("Test 2");
	}
}
