package com.applitools;

import java.awt.Robot;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.EyesRunner;
import com.applitools.eyes.TestResultsSummary;
import com.applitools.eyes.selenium.ClassicRunner;
import com.applitools.eyes.selenium.Eyes;

public class BasePage {
	
	public static EyesRunner runner;
	public static Eyes eyes;
	public static BatchInfo batch;
	public static WebDriver driver;
	public static Robot robot;
	public static WebDriverWait wait;
	public static Actions actions;
	
	@BeforeTest
	public static void config() {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");

		runner = new ClassicRunner();
	    eyes = new Eyes(runner);
	    
	    eyes.setApiKey("13znX3phX8NFD3Epr2KLJZGLn8qs6BWfY1mOwFoxf1084110");
	    
	    driver = new ChromeDriver();
		
	}
	
	@AfterTest
	public static void close() {
		
		eyes.closeAsync();

		// Wait and collect all test results
		TestResultsSummary allTestResults = runner.getAllTestResults();

		// Print results
		System.out.println(allTestResults);

		driver.quit();
	}

}
