package com.applitools;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.TestResultsSummary;

public class Deliverables extends Base{

	@Test
	public void DeliverablesTest() throws Exception {
		
		eyes.open(driver, "Deliverables", "Deliverables-Demo", new RectangleSize(800, 600));
		driver.get("http://10.0.5.26:8100/");;
		driver.manage().timeouts().setScriptTimeout(20, TimeUnit.SECONDS);
		
		wait = new WebDriverWait(driver,120);
		
		eyes.checkWindow("Login Page");		
		
		WebElement user = driver.findElement(By.name("txtUID"));
		user.sendKeys("1009");
		
		WebElement password = driver.findElement(By.name("txtPWD"));
		password.sendKeys("vkg");
		
		WebElement signin = driver.findElement(By.xpath("//input[@value='Sign in']"));
		signin.click();
		
		Thread.sleep(5000);
		
		eyes.checkWindow("Home Page");
		
		WebElement cust_dropdown = driver.findElement(By.name("cboCustomer"));
		cust_dropdown.click();
		
		WebElement cust_option1 = driver.findElement(By.xpath("//select[@name='cboCustomer']/option[2]"));
		cust_option1.click();
		
		Thread.sleep(2000);
		
		WebElement stage_dropdown = driver.findElement(By.name("cboStage"));
		stage_dropdown.click();
		
		WebElement stage_option1 = driver.findElement(By.xpath("//select[@name='cboStage']/option[2]"));
		stage_option1.click();
		
		Thread.sleep(2000);
		
		WebElement journal_dropdown = driver.findElement(By.name("cboJournal"));
		journal_dropdown.click();
		
		WebElement journal_option1 = driver.findElement(By.xpath("//select[@name='cboJournal']/option[2]"));
		journal_option1.click();
		
		Thread.sleep(2000);
		
		WebElement article_dropdown = driver.findElement(By.name("cboArticle"));
		article_dropdown.click();
		
		WebElement article_option1 = driver.findElement(By.xpath("//select[@name='cboArticle']/option[2]"));
		article_option1.click();
		
		Thread.sleep(5000);
		
		WebElement CheckAll = driver.findElement(By.xpath("//input[@name='CheckAll']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('value','CheckAll')", CheckAll);
		js.executeScript("arguments[0].setAttribute('style','background-color:red')", CheckAll);
		
		WebElement Error = driver.findElement(By.xpath("//input[@value='Error/Warnings']"));
		js.executeScript("arguments[0].setAttribute('value','Error Warnings')", Error);
		
		
		eyes.checkWindow("Home Page - List of Journals");
		
			
		driver.findElement(By.xpath("//input[contains(@value,'BPS14404.xml')]")).click();
		
		eyes.checkWindow("Home Page - After Journal selection");
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[contains(@value,'Edit Issue-XML')]")).click();
		
		Thread.sleep(5000);
		
		eyes.checkWindow("Issue XML Editing Interface");
		
		Thread.sleep(2000);
		
//		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight);");
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[contains(text(),'Close')]")).click();
		
		Thread.sleep(2000);
		
		eyes.checkWindow("Back to Home Page - Unselected");
		
		driver.findElement(By.xpath("//input[@name='CheckAll']")).click();
		
		eyes.checkWindow("Home Page - All selected");
		
		driver.findElement(By.xpath("//input[@value='Clear']")).click();
		
		Thread.sleep(5000);
		
		eyes.checkWindow("Home Page - Cleared");
		
		
		
		
		
		
		
		
		
		
		
		
		
		eyes.closeAsync();

		// Wait and collect all test results
		TestResultsSummary allTestResults = runner.getAllTestResults();

		// Print results
		System.out.println(allTestResults);

		driver.quit();
		
		}
	
}
