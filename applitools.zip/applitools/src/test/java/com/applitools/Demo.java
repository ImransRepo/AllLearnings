package com.applitools;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.EyesRunner;
import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.TestResultsSummary;
import com.applitools.eyes.selenium.ClassicRunner;
import com.applitools.eyes.selenium.Eyes;

public class Demo {

	public static EyesRunner runner;
	public static Eyes eyes;
	public static BatchInfo batch;
	public static WebDriver driver;

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");

		runner = new ClassicRunner();
	    eyes = new Eyes(runner);
	    
	    eyes.setApiKey("13znX3phX8NFD3Epr2KLJZGLn8qs6BWfY1mOwFoxf1084110");
	    
	    driver = new ChromeDriver();
	    
	    eyes.open(driver, "Demo App", "Smoke Test", new RectangleSize(800, 275));
	    driver.get("https://demo.applitools.com");
	    
	    eyes.checkWindow("Login Window");
	    
	    driver.findElement(By.id("log-in")).click();
	    eyes.checkWindow("App Window");
	    
	    eyes.closeAsync();

	    // Wait and collect all test results
	    TestResultsSummary allTestResults = runner.getAllTestResults();

	    // Print results
	    System.out.println(allTestResults);

	    driver.quit();

	    
	    
	    


		
	}

}
