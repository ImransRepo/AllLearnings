package com.applitools;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.EyesRunner;
import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.TestResultsSummary;
import com.applitools.eyes.selenium.ClassicRunner;
import com.applitools.eyes.selenium.Eyes;

public class Nimble extends BasePage {

	@Test
	public static void Nimble() throws InterruptedException {

		eyes.open(driver, "Nimble QA", "Nimble - Demo", new RectangleSize(800, 600));
		driver.get("http://10.0.5.128:6062/S&T/app.html");

		Thread.sleep(5000);
		
		WebElement login = driver.findElement(By.xpath("//input[@name='signin']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('value','LOG')", login);
		
		Thread.sleep(5000);
		
		eyes.checkWindow("Login Window");

		driver.findElement(By.id("username")).sendKeys("automatenimble");
		driver.findElement(By.id("password")).sendKeys("nimble");
		driver.findElement(By.xpath("//input[@name='signin']")).click();

		Thread.sleep(5000);

		eyes.checkWindow("Home Page Window");
		
		WebElement journalID = driver.findElement(By.xpath("(//span[text()='Journal ID'])[1]"));
		

		driver.findElement(By.xpath("//*[text()='Assign Task']")).click();
		
		Thread.sleep(10000);

		eyes.checkWindow("Assign Task Window");
		
		driver.findElement(By.xpath("//*[text()='Task Report']")).click();
		Thread.sleep(10000);
		
		eyes.checkWindow("Task Report Window");
		
		driver.findElement(By.xpath("//*[text()='Modify Articles / Issues']")).click();
		Thread.sleep(10000);

		Thread.sleep(15000);
		
		eyes.checkWindow("Modify Articles / Issues Window");

		driver.findElement(By.xpath("//span[text()='Reports']")).click();
		driver.findElement(By.xpath("//span[text()='Article History']")).click();

		Thread.sleep(15000);

		eyes.checkWindow("Reports - Article History Window");
		

	}

}
