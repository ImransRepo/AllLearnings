package com.applitools;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.TestResultsSummary;

public class PgC extends Base{

	@Test
	public void PgCTest() throws Exception {
		
		eyes.open(driver, "Page Central", "Smoke Test - PgC", new RectangleSize(800, 600));
		driver.get("https://elsevierqa.proofcentral.com/en-us/index.html?token=6e395049fb89300cf50979ecf81330");;
		driver.manage().timeouts().setScriptTimeout(20, TimeUnit.SECONDS);
		
		wait = new WebDriverWait(driver,120);
		
		WebElement initializing = driver.findElement(By.xpath("//label[text()='Initializing...']"));
		wait.until(ExpectedConditions.invisibilityOf(initializing));
		
		Thread.sleep(5000);
		
		WebElement skipButton = driver.findElement(By.xpath("//button[text()='Skip Tour']"));
		wait.until(ExpectedConditions.elementToBeClickable(skipButton));
		skipButton.click();
		
		Thread.sleep(15000);
		
		WebElement proofButton = driver.findElement(By.xpath("//button[@class='groupbtn__button groupbtn__button--active']//following::button[1]"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", proofButton);
		
		Thread.sleep(15000);
		
		WebElement continueButton = driver.findElement(By.xpath("//button[text()='Continue']"));
		wait.until(ExpectedConditions.elementToBeClickable(continueButton));
		continueButton.click();
		
		eyes.checkWindow("Page Central Home Page");
		
		for(int i=1; i<5; i++) {
		
		js.executeScript("window.scrollBy(0,200)");
		eyes.checkWindow("PgC - Scroll "+ i);
		
		}
		
		eyes.closeAsync();

		// Wait and collect all test results
		TestResultsSummary allTestResults = runner.getAllTestResults();

		// Print results
		System.out.println(allTestResults);

		driver.quit();
		
		}
	
}
