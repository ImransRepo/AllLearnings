package com.applitools;

import java.awt.Robot;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PrC {

	public static WebDriver driver;
	public static Robot robot;
	public static WebDriverWait wait;
	public static Actions actions;

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();

		driver.get("https://elsevierqa.proofcentral.com/es-es/landing-page.html?token=2c022f3e06d754097d402047dc5c91");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		wait = new WebDriverWait(driver, 120);
		actions = new Actions(driver);

		driver.findElement(By.xpath("//input[@class='btn proceed']")).click();

		ArrayList<String> handles = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(handles.get(1));

		Thread.sleep(3000);

		WebElement initializing = driver.findElement(By.xpath("//label[contains(text(),'Initializing')]"));
		wait.until(ExpectedConditions.invisibilityOf(initializing));

		WebElement skiptour = driver.findElement(By.xpath("//button[text()='Skip Tour']"));
		wait.until(ExpectedConditions.elementToBeClickable(skiptour)).click();

		wait.until(ExpectedConditions
				.elementToBeClickable(driver.findElement(By.xpath("//button[@data-name='pagecentral-button']"))));

		WebElement title = driver.findElement(By.xpath(
				"//h1[text()=' Polymorphisms of Adrenoceptors are not Associated with an Increased Risk of Adverse Event in Heart Failure: A MERIT-HF Substudy']"));
		title.click();

		actions.doubleClick(title);

		System.out.println("Double Clicked");

	}

}
