package com.applitools;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.EyesRunner;
import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.selenium.ClassicRunner;
import com.applitools.eyes.selenium.Eyes;

public class ProofCentral extends BasePage{

	@Test
	public static void PrC() throws InterruptedException {
			    
	    eyes.open(driver, "PrC", "Smoke Test-PrC", new RectangleSize(800, 600));
	    
	    driver.get("https://elsevierqa.proofcentral.com/es-es/landing-page.html?token=2c022f3e06d754097d402047dc5c91");
	    driver.manage().window().maximize();
	    Thread.sleep(3000);
	    wait = new WebDriverWait(driver,120);
	    actions = new Actions(driver);
	    
	    eyes.checkWindow("PrC - Home Page");
	    
		Thread.sleep(3000);
	    
	    driver.findElement(By.xpath("//input[@class='btn proceed']")).click();
	    
		ArrayList<String> handles = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(handles.get(1));
		
		Thread.sleep(3000);
		
		WebElement initializing = driver.findElement(By.xpath("//label[contains(text(),'Initializing')]"));
		wait.until(ExpectedConditions.invisibilityOf(initializing));
		
		WebElement skiptour = driver.findElement(By.xpath("//button[text()='Skip Tour']"));
		wait.until(ExpectedConditions.elementToBeClickable(skiptour)).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//button[@data-name='pagecentral-button']"))));
		
		eyes.checkWindow("PrC - Main Page");
		
		WebElement title = driver.findElement(By.xpath("//h1[text()=' Polymorphisms of Adrenoceptors are not Associated with an Increased Risk of Adverse Event in Heart Failure: A MERIT-HF Substudy']"));
		title.click();
		
		actions.doubleClick(title);
		
		driver.findElement(By.xpath("(//button[@title='Bold (Ctrl+B)'])[1]")).click();
		driver.findElement(By.xpath("(//button[@title='Italic (Ctrl+I)'])[1]")).click();
		
		eyes.checkWindow("Prc - Main Page - After Edit");
		
	    
	    
		
	}

}
