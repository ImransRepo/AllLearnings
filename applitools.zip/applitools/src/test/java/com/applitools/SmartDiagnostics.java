package com.applitools;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.EyesRunner;
import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.selenium.ClassicRunner;
import com.applitools.eyes.selenium.Eyes;

public class SmartDiagnostics extends BasePage {

	@Test
	public static void SmD() throws AWTException, InterruptedException {

		
		eyes.open(driver, "SmD", "Smoke Test - SmD", new RectangleSize(800, 600));
		
		driver.get("https://www.smartcentral.ai/service/smart-diagnostics");
		driver.manage().window().maximize();

		Thread.sleep(5000);

		eyes.checkWindow("Home Page Window");

		WebElement signup = driver.findElement(By.linkText("Sign up"));
		signup.sendKeys(Keys.PAGE_DOWN);

		Thread.sleep(3000);

		driver.findElement(By.xpath("//span[text()='Choose files']")).click();

		Thread.sleep(5000);

		StringSelection strSelect = new StringSelection(
				"C:\\Users\\TNQ\\Desktop\\Artikel3EEDR_revision2_maintext_02_finalsubmittedversion.docx");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(strSelect, null);

		robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);

		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);

		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		eyes.checkWindow("SmD Window - After File Upload");
		
		driver.findElement(By.xpath("//button[text()=' SUBMIT']")).click();
		
		WebElement viewresult = driver.findElement(By.id("viewresult"));
		wait = new WebDriverWait(driver,120);
		wait.until(ExpectedConditions.elementToBeClickable(viewresult));
		
		eyes.checkWindow("SmD Window - After File Processing Complete");
		
		viewresult.click();
		
		ArrayList<String> handles = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(handles.get(1));
		
		Thread.sleep(3000);
		
		eyes.checkWindow("View Result Window");
		
		
		

	}

}
