package nimble;

import java.awt.Robot;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;

public class SwitchAndClose {
	
	public static WebDriver driver;
	public static Robot robot;
	public static WebDriverWait wait;
	public static Actions actions;
	
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.get("http://10.0.5.128:6062/S&T/app.html");
		
		driver.findElement(By.id("username")).sendKeys("automatenimble");
		driver.findElement(By.id("password")).sendKeys("nimble");
		driver.findElement(By.xpath("//input[@name='signin']")).click();

		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//span[text()='Reports']")).click();
		driver.findElement(By.xpath("//span[text()='Article History']")).click();
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("(//input[@name='journalID']//following::div[1])[1]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//li[text()='AAT']")).click();
		
		driver.findElement(By.xpath("//input[@name='article']")).sendKeys("454343");;
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[text()='Submit']")).click();
		
		ArrayList<String> homeHandles = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(homeHandles.get(1));
		
		Thread.sleep(5000);
	
		SwitchAndClose.closetabandswitch();
		
		System.out.println("Closed New tab");
		
		driver.findElement(By.xpath("(//span[text()='Reset'])[1]")).click();
		
	}
	
	
	public static void closetabandswitch() {
		
		ArrayList<String> windowhandles = new ArrayList<String>(driver.getWindowHandles());
		driver.close();
		driver.switchTo().window(windowhandles.get(0));
		
		
		
		
	}

}
