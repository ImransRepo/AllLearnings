package atos.interviewQuestions;

import java.util.HashMap;
import java.util.Map;

public class OccuranceOfChars {

	public static void main(String[] args) {

		
		// Using HashMap
		
		String str = "HelloWorldContinue";

		char[] charArray = str.toCharArray();

		Map<Character,Integer> map = new HashMap<Character,Integer>();

		for( char ch : charArray){

			if( map.containsKey(ch)){
			
				map.put(ch, map.get(ch)+1);
			}
			else{
			
				map.put(ch,1);
			
			}
		}

			System.out.println(map);
			
		// Using charAt;
			
		String str2 = "AllisWell";
		int count = 0;
		char c = str2.charAt(0);
		
		for(int i=0; i<str2.length(); i++) {
			
			if(c == str2.charAt(i)) {
				
				count++;
				
			}
			
		}
		
		System.out.println(c + " occurs "+count+" times in "+ str2);

		
		
		
	}

}
