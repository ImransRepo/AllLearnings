package atos.interviewQuestions;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class RemoveArrayDuplicates {

	public static void main(String[] args) {

		/* Using Set */
		
		 int arr[] = {2,3,2,5,1,3,4,7,1};
		    
		    Set<Integer> set1 = new LinkedHashSet<Integer>();
		    
		    for(Integer each: arr){
		        
		        set1.add(each);
		        
		    }
		    
		      System.out.println("Array without Duplicates: "+ set1);
		
		// Using Temp Array
		      
		 System.out.println("Remove Duplicates Using Temp Array ");
		 
		 int array[] = {1,2,2,3,4,4,5,5,6};
		 
		 int size = array.length;
		 
		 int temp[] = new int[size];
		 
		 int j = 0;
		 
		for(int i=0; i<size-1; i++) {
			
			if(array[i] != array[i+1]) {
				
				temp[j] = array[i];
				j++;
				
			}
		}
		
		temp[j] = array[size-1];
				
		for(int i=0; i<=j; i++) {
			
			array[i] = temp[i];
			System.out.print(array[i]+" ");
		}
		 
		System.out.println("-------------------------------");
		System.out.println("Remove Duplicates using hashmap");
		System.out.println("-------------------------------");
		
		// Using HashMap
		
		int a[]= {1,2,2,3,4,4,5,5,6};
		
		Map<Integer,Boolean> map1 = new HashMap<Integer,Boolean>();
		
		for(int i=0; i<a.length;i++) {
			
			if(map1.get(a[i]) == null) {
				System.out.print(a[i]+" ");
				map1.put(a[i], true);
			}
			
		}
		

		
		
	}

}
