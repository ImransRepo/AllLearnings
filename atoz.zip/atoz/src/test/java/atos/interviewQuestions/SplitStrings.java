package atos.interviewQuestions;

import java.util.Arrays;

public class SplitStrings {

	public static void main(String[] args) {

		String str = "OTP for login is 789789 and REFERENCE number is 434332";
		
		String[] split = str.split("is");
//		System.out.println(Arrays.toString(split));
		
		for(int i=1; i<split.length; i++) {
			
			System.out.println(split[i].replaceAll("[^0-9]", " ").trim());
			
		}
		
		
		
		
	}

}
