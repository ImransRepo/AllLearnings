package boa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public void connect(String user, String password) {
		try {
		
			Connection connection = DriverManager.getConnection("", user, password);
			PreparedStatement statement = connection.prepareStatement("");
			ResultSet rs = statement.executeQuery();
			
			while(rs.next()) {
				
				String fname = rs.getString("");
				System.out.println(fname);
				
			}
			
			
		}catch(Exception e) {
			
			System.out.println(e);
		}
		
		
		
		
		
		
	}

}
