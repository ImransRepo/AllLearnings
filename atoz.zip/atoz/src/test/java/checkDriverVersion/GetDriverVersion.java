package checkDriverVersion;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class GetDriverVersion {

	public static void main(String[] args) {

		System.setProperty("webdriver.gecko.driver", "./driver/geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		DesiredCapabilities dc = DesiredCapabilities.firefox();
		
	}

}
