package otherPrograms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Intersection {

	public static void main(String[] args) {

		int arr1[] = {1,2,5,6,3,4}, arr2[] = {2,3,4,7,8,0};
		
		List<Integer> l1 = new ArrayList<Integer>();
		
		for(int i=0; i<arr1.length; i++) {
			
			for(int j=0; j<arr2.length; j++) {
				
				if(arr1[i] == arr2[j]) {
					
					l1.add(arr2[j]);
					
				}
				
			}
			
			
		}
		
		Collections.sort(l1);
		
		System.out.println(l1);
		
		
	}

}
