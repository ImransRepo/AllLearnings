package otherPrograms;

import java.util.Arrays;
import java.util.Collections;

public class Min_Max {

	public static void main(String[] args) {
		
//		Using Collections.Min_Max

		Integer a1[] = {2,3,100,6,7,2,4,5};
		
		Integer max = Collections.max(Arrays.asList(a1));
		System.out.println(max);

		Integer min = Collections.min(Arrays.asList(a1));
		System.out.println(min);
		
//		Using Arrays.sort
		
		Arrays.sort(a1);
		
		System.out.println("Max: "+ a1[a1.length-1]);
		System.out.println("Min: "+ a1[0]);
		
//		Using For Loop
		
		int min1 = a1[0];
		int max1 = a1[0];
		
		for(int i=0; i<a1.length; i++) {
			
			if(a1[i]>max1) {
				
				max1 = a1[i];
				
			}
			else if(a1[i]<min1){
				
				min1 = a1[i];
				
			}
		}
		
		
		System.out.println("Min Value is: "+ min1);
		System.out.println("Max Value is: "+ max1);
		
	}

}
