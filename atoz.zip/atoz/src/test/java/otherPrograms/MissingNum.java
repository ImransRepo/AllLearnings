package otherPrograms;

public class MissingNum {

	public static void main(String[] args) {

		int[] a = {1,2,4,5,7,9};
		
		for(int i=1; i<a.length; i++) {
			
			if(i != a[i-1]) {
				
				System.out.println("Missing element is: "+ i);
				
			}
			
		}
		
	}

}
