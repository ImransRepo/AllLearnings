package otherPrograms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class PrintDuplicates {

	public static void main(String[] args) {

		 int a[] = {1,2,5,6,3,2,5,4,6,4};
	     
	     Arrays.sort(a);
	     
	     List<Integer> l1 = new ArrayList<Integer>();
	     
	     for(int i=0; i<a.length-1; i++){
	         
	         if(a[i] == a[i+1]){
	             
	             l1.add(a[i]);
	             
	         }
	     }
	     
	     System.out.println("Duplicates in the array are: "+l1);
	     
	     
//	     Using Set
	     
	     int b[] = {2,3,4,2,3,4,6,7,8,7};
	     
	     Set<Integer> s1 = new HashSet<Integer>();
	     
	     for(int i=0; i<b.length; i++) {
	    	 
	    	 if(!s1.add(b[i])) {
	    		 
	    		 System.out.println("The Duplicates are: "+ b[i]);
	    	 }
	     }
	     
//	     Using Map

	     int a2[] = {1,2,5,6,3,2,5,4,6,4};
	     
	     Map<Integer,Integer> m1 = new HashMap<Integer,Integer>();
	     
	     for(int i=0; i<a2.length; i++){
	         
	         if(m1.containsKey(a2[i])){
	             
	             m1.put(a2[i], m1.get(a2[i])+1);
	             
	         }
	         
	         else{
	             
	             m1.put(a2[i],1);
	         }
	         
	     }
	     
	     
	     for(Entry<Integer,Integer> each : m1.entrySet()){
	         
	         if(each.getValue()>1){
	             
	             System.out.println("Duplicates are: "+ each.getKey());
	             
	         }
	         
	     }
			
		}
		
	}


