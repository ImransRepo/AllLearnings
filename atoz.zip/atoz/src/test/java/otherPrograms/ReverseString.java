package otherPrograms;

public class ReverseString {

	public static void main(String[] args) {

		String str1 = "ALL IS WELL";
		String str2 = "IMRAN HUSSAIN";
		String str3 = "MISSION IMPOSSIBLE";
				
				
		for(int i=str1.length()-1; i>=0; i--) {
			
			System.out.print(str1.charAt(i));
			
		}
		
		System.out.println("");
		
		char[] cr = str2.toCharArray();
		
		for(int i=cr.length-1; i>=0; i--) {
			
			System.out.print(cr[i]);
			
		}
		
		
		System.out.println("");
		
		StringBuilder sb = new StringBuilder(str3);
		StringBuilder reverse = sb.reverse();
		
		System.out.println(reverse);
		
		
	}

}
