package trustrace.interviewQuestions;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class AnnotationsFlow {
	
	
	@Test
	void test1() {
		System.out.println("Test 1");
	}

	@Test
	void test2() {
		System.out.println("Test 2");
	}
	
	@BeforeClass
	void beforeClass() {
		System.out.println("Before Class");
		
	}
	
	@BeforeMethod
	void beforeMethod() {
		System.out.println("Before Method");
		
	}
	
}
