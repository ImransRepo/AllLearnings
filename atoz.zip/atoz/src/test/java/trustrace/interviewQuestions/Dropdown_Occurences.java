package trustrace.interviewQuestions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Dropdown_Occurences {

	public static void main(String[] args) {

		
		  WebDriverManager.chromedriver().setup(); WebDriver driver = new
		  ChromeDriver();
		  
		  driver.get("http://www.leafground.com/pages/Dropdown.html"); WebElement
		  dropdown = driver.findElement(By.xpath("//select[@class='dropdown']"));
		  
		  Select select = new Select(dropdown); 
		  List<WebElement> options =  select.getOptions();
		  
		  Map<String,Integer> map = new HashMap<String,Integer>();
		  
		  for(int i =0; i<options.size(); i++) {
			  
			  String key = options.get(i).getText();
			  if(map.containsKey(key)) {
				  
				  map.put(key, map.get(key)+1);
				  
			  }
			  else {
				  
				  map.put(key, 1);
				  
			  }
			  
		  }
		  
			System.out.println(map);

				 

		// Solution 1
		
		/*List<String> list = new ArrayList<String>();
		list.add("Selenium");
		list.add("QTP");
		list.add("Selenium");
		list.add("QTP");
		list.add("Load");

		Set<String> set = new HashSet<String>(list);
		for (String each : set) {

			System.out.println(each+": "+Collections.frequency(list, each));
		}*/
	}

}
