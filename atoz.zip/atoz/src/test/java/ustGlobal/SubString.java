package ustGlobal;

public class SubString {

	public static void main(String[] args) {

		String str = "abcdefghijk12345";
		str = str.replaceAll("[^0-9]", "");
		System.out.println(str);
		
		String a = "ust", b ="global";
		System.out.println(a+":"+b);
		
		a=a+b;
		
		b = a.substring(0, a.length()-b.length());
		a = a.substring(b.length());
		
		System.out.println(a+":"+b);
		
		
		int i = 10 , j =20;
		System.out.println(i+":"+j);
		i = i+j;
		j = i-j;
		i = i-j;
		
		System.out.println(i+":"+j);
		
		
		
		
		
	}

}
