package javaprograms;

import java.util.Arrays;

public class ArrayPairs {

	public static void main(String[] args) {

		int[] a1 = {1,2,3,4,5,6,7,8};
		int length = a1.length;
		
		int temp[] = null;
		int[] newArr = null;
		
		
		// get first 2 elements
		// display in array
		// Iterate through next 2 
				
		for(int i=0; i<a1.length; i++) {
		
			System.out.println("("+ a1[i] +","+ a1[i+1]+")");
			/*temp = new int[] {a1[i],a1[i+1]};
			newArr = Arrays.copyOfRange(a1, i, i+1);*/
			i = i+1;
			
		}
		
		/*for(int each: newArr) {
			
			System.out.println(each);
			
		}*/
	}

}
