package javaprograms;

public class MinAndMax {

	public static void main(String[] args) {

		int[] a1 = {1,4,2,7,3,6,2,9,0,5};
		
		int largest = a1[0];
		int smallest = a1[0];
		
		for(int i=0; i<a1.length; i++) {
			
			if(a1[i] > largest) {
				
				largest = a1[i];
			}
			else if(a1[i]<smallest) {
				
				smallest = a1[i];
			}
			
		}
		
		System.out.println("Largest Num is: "+ largest);
		System.out.println("Smallest Num is: "+ smallest);
		
	}

}
