package com.dsandalgo;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collections;

public class DS1_Arrays {

	public static void main(String[] args) {
		
		DArray array = new DArray(5);
		array.insert(10);
		array.insert(20);
		array.insert(30);
		array.insert(100);
		array.insert(40);
		array.insert(50);
		array.print();

		System.out.println("------------");

		// Insert Data at a Particular Index in the array

		array.insertAt(1, 1);
		array.print();

		System.out.println("------------");

		// Remove Data from a Particular Index in the array

		array.removeAt(5);
		array.print();

		System.out.println("------------");

		System.out.println("Largest Num is: " + array.max());

		System.out.println("------------");

		// Reverse the elements in an array

		array.reverse();
		array.print();

		System.out.println("------------");

		// Identify Index of Particular element in an array

		int indexOf = array.indexOf(100);
		System.out.println("Index Of Item is: " + indexOf);

	}

}

class DArray {

	private int items[];
	private int count;

	public DArray(int size) {

		items = new int[size];
	}

	public void insert(int item) {

		// Check if Array is full

		if (items.length == count) {

			int[] newItems = new int[count * 2]; // Create new Array double the size of existing array

			for (int i = 0; i < count; i++) {

				newItems[i] = items[i]; // Copy data from old to new array

			}

			items = newItems; // Copy back to items[] array

		}

		items[count++] = item;
	}

	public void removeAt(int index) {

		if (index < 0 || index >= count)
			throw new IllegalArgumentException();
			

		for (int i = index; i < count; i++)
			items[i] = items[i + 1];

		count--;

	}

	public int indexOf(int item) {

		for (int i = 0; i < count; i++) {

			if (items[i] == item) {

				return i;
			}

		}

		return -1;
	}

	public void print() {

		for (int i = 0; i < count; i++)
			System.out.println(items[i]);

		System.out.println("Array Length: " + items.length);
		System.out.println("Count: " + count);

	}

	public int max() {

		int lnum = items[0];

		for (int i = 0; i < count; i++) {

			if (items[i] > lnum)
				lnum = items[i];

		}

		return lnum;
	}

	public void reverse() {

		for (int i = count - 1; i >= 0; i--)
			System.out.print(items[i] + ",");

		System.out.println();

	}

	public void insertAt(int item, int index) {

		// Check if the particular index within range
		// Check if the index is free
		// If yes, insert the element
		// If Not, shift the elements to consecutive indexes & insert

		if (index < 0 && index >= count)
			throw new IllegalArgumentException();

		else if (items[index] == 0)
			items[index] = item;

		else {

			for (int i = count - 1; i >= index; i--)
				items[i + 1] = items[i];

			items[index] = item;
		}
	}
	
	public void intersect(DArray arr1, DArray arr2) {
		
		for(int i=0; i<arr1.count; i++) {
			for(int j=0; j<arr2.count; j++) {
				
				if(arr1.items[i]==arr2.items[j]) {
					System.out.print(arr1.items[i]+",");
					break;
				}
			}
			
		}
		
		
	}

}
