package com.dsandalgo;

public class DS1_Arrays_Intersect {

	public static void main(String[] args) {

		DArray a3 = new DArray(5);
		
		DArray a1 = new DArray(4);
		a1.insert(1); a1.insert(2); a1.insert(3); a1.insert(4);
		DArray a2 = new DArray(4);
		a1.insert(6); a1.insert(5); a1.insert(4); a1.insert(3);
		
		a3.intersect(a1, a2);
		
		
		
	}

}
