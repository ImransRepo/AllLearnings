package com.dsandalgo;

import java.util.ArrayList;

public class DS2_ArrayList {

	public static void main(String[] args) {

		ArrayList<Integer> al = new ArrayList<Integer>();
		
		al.add(20);
		al.add(30);
		al.add(20);
		
		int indexOf = al.indexOf(40);
		System.out.println(indexOf);
		
		int lastIndexOf = al.lastIndexOf(40);
		System.out.println(lastIndexOf);
		
	}

}
