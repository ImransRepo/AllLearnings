package com.dsandalgo;

public class IncrementNDecrement {

	public static void main(String[] args) {

		int i = 1, j= 10;
		
		i++;
		++j;
		
		System.out.println(i);
		System.out.println(j);
		
		System.out.println("------------");
		
		i--;
		--j;

		System.out.println(i);
		System.out.println(j);

		int[] a = new int[3];
		
		
		
		
	}

}
