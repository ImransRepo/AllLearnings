package com.dsandalgo;

public class LinkedListMain {

	public static void main(String[] args) {

		DS3_LinkedList list = new DS3_LinkedList();
		list.addLast(20);
		list.addLast(30);
		list.addLast(40);
		
	}

}
