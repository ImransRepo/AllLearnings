package allAboutSelenium;

import java.io.File;
import java.io.FileNotFoundException;

import org.codehaus.plexus.util.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TakeScreenshot {
	
	
	public static void main(String[] args) throws FileNotFoundException, Exception {
		
		TakeScreenshot ts = new TakeScreenshot();
		ts.takescreenshot();
		
		
		
	}
	
	public void takescreenshot() throws FileNotFoundException, Exception {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File src = ts.getScreenshotAs(OutputType.FILE);
		File dest = new File("./image.png");
		FileUtils.copyFile(src, dest);
		
		
		
	}

}
