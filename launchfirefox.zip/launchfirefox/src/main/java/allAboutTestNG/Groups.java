package allAboutTestNG;

import org.testng.annotations.Test;

public class Groups {

	@Test(groups= {"functional"})
	void functest1() {
		System.out.println("Functional Test 1");
	}

	@Test(groups= {"functional"})
	void functest2() {
		System.out.println("Functional Test 2");
	}

	@Test(groups= {"sanity"})
	void sanity1() {

		System.out.println("Sanity 1");
	}

	@Test(groups= {"sanity"})
	void sanity2() {

		System.out.println("Sanity 2");
	}
}
