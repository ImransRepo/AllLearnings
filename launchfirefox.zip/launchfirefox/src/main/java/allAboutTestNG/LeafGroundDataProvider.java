package allAboutTestNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LeafGroundDataProvider {
	
	static WebDriver driver;
	
	@BeforeSuite
	public void setUp() throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		options.addArguments("--start-maximized");	
		
		driver = new ChromeDriver(options);
		driver.get("http://www.leafground.com/pages/Edit.html");
		
			
	}
	
	@Test(dataProvider="getData")
	public void editPage(String emailID) throws InterruptedException {
		
		WebElement email = driver.findElement(By.xpath("//label[text()='Enter your email address']/following::input"));
		email.sendKeys(emailID);
		Thread.sleep(5000);
		email.clear();
		
	}
	
	
	@DataProvider
	public String[] getData(){
		
		String[] data = new String[2];
		data[0]="test1@gmail.com";
		data[1]="test2@hotmail.com";
		
		return data;
		
		
		
	}
	
	
	
	
	

}
