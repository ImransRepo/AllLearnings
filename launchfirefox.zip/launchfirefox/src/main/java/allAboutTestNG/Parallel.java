package allAboutTestNG;

import org.testng.annotations.Test;

@Test(groups = {"class1"})
public class Parallel {
	
//	@Test(groups= {"functional"})
	public void functest1() {
		System.out.println("Functional Test 1");
	}

//	@Test(groups= {"functional"})
	public void functest2() {
		System.out.println("Functional Test 2");
	}

//	@Test(groups= {"sanity"})
	public void sanity1() {

		System.out.println("Sanity 1");
	}

//	@Test(groups= {"sanity"})
	public void sanity2() {

		System.out.println("Sanity 2");
	}

}

@Test
class Class2{
	
//	@Test(groups= {"smoke"})
	public void functest1() {
		System.out.println("smoke Test 1");
	}

//	@Test(groups= {"smoke"})
	public void functest2() {
		System.out.println("smoke Test 2");
	}
	
}
