package allAboutTestNG;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class UseProperties {
	
	static String configFilePath = "./config/configuration.properties";
	static WebDriver driver;
	
	@BeforeSuite
	void config() throws Exception {
		
		String path = properties(configFilePath).getProperty("driverPath").trim();
		String url = properties(configFilePath).getProperty("url");
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		
		System.setProperty("webdriver.chrome.driver", path);
		driver = new ChromeDriver(options);
		driver.get(url);
		
	}
	
	@Test
	void setUp() {
		
		System.out.println(driver.getTitle());
		
	}
	
	public Properties  properties(String path) throws Exception {
		
		FileInputStream fis = new FileInputStream(path);
		Properties properties = new Properties();
		properties.load(fis);
		return properties;
	}

}
