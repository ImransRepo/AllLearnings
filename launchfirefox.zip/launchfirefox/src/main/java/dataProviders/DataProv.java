package dataProviders;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DataProv {
	
static WebDriver driver;
	
	@BeforeSuite
	public void setUp() {
		
		WebDriverManager.chromedriver().setup();
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		options.addArguments("--start-maximized");	
		
		driver = new ChromeDriver(options);
		driver.get("https://www.google.com");
	
	}
	
	@Test(dataProvider="getData")
	public void editPage(String key1, String key2) throws InterruptedException {
		
		WebElement search = driver.findElement(By.xpath("//input[@class='gLFyf gsfi']"));
		search.sendKeys(key1,key2);
		Thread.sleep(5000);
		search.clear();
		
	}
	
	@DataProvider
	public Object[][] getData(){
		
		return new Object[][]{
          	{"Selenium","Delhi"},{"QTP","Bangalore"},{"LoadRunner","Chennai"}
    	};
		
		
		
	}
	

}
