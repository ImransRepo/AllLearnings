package dataProviders;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ReadExcelFile {
	
	@Test
	public void readExcel() throws Exception{
		
		FileInputStream fis = new FileInputStream("C:\\Users\\TNQ\\Desktop\\TestData.xlsx");
		XSSFWorkbook book = new XSSFWorkbook(fis);
		XSSFSheet sheet = book.getSheetAt(0);
		int lastRowNum = sheet.getLastRowNum();
		Row firstrow = sheet.getRow(0);
		int lastCellNum = firstrow.getLastCellNum();
		
		String data[][] = null;
		
		for(int i=1; i<=lastRowNum-1; i++) {
			
			XSSFRow row = sheet.getRow(i);
			
			for(int j=0; j<=lastCellNum-1; j++) {
				
				String cellValue = row.getCell(j).getStringCellValue();
				data[i-1][j]=cellValue;
				System.out.println("data"+ cellValue);
			}
			
		}
		
//		return data;
		
		
	}

}
