package launchFirefox;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

public class AlternateForSendKeys extends BasePage {
	
	@Test
	public void typeUsingJSE() throws InterruptedException {
		
		driver.get("https://github.com/login");
		Thread.sleep(5000);

		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("document.getElementById('login_field').setAttribute('value','imran');");
		jse.executeScript("document.getElementById('password').setAttribute('value','imran');");
		Thread.sleep(5000);
		driver.quit();
		
		
	}

}
