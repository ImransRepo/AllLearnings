package launchFirefox;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BasePage {

	public static WebDriver driver;
//	public static RemoteWebDriver driver;
	public static ChromeOptions options;

	@BeforeTest
	public static void openUrl() throws InterruptedException {

		/*System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");*/
		WebDriverManager.chromedriver().setup();

		DesiredCapabilities dc = new DesiredCapabilities();
		dc.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
		options = new ChromeOptions();
		/*options.addArguments("--headless");*/

		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		
		/* To Identify Browser Version,Platform while running the script */
		Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
		String browserName = caps.getBrowserName();
		String browserVersion = caps.getVersion();
		String Platform = caps.getPlatform().toString();

		System.out.println(Platform+" : " + browserName + " : " + browserVersion);

	}

}
