package launchFirefox;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrokenLinks {

	private static WebDriver driver;

	@Test
	public static void identifyBrokenLinks() throws IOException {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		String homeUrl = "https://www.zlti.com/";
		String url = "";
		int statusCode = 200;
		HttpURLConnection huc = null;

		driver.get(homeUrl);

		List<WebElement> links = driver.findElements(By.tagName("a"));

		Iterator<WebElement> it = links.iterator();

		while (it.hasNext()) {

			url = it.next().getAttribute("href");
			System.out.println("URL is : " + url);

			if (url == null || url.isEmpty()) {

				System.out.println("Url is empty");

			}

			else if (!url.startsWith(homeUrl)) {

				System.out.println("Url doesn't belong to this domain");
			}

			try {

				huc = (HttpURLConnection) new URL(url).openConnection();
				huc.setRequestMethod("HEAD");
				huc.connect();

				statusCode = huc.getResponseCode();

				if (statusCode >= 400) {
					System.out.println(url + ": Invlaid Link"+" Status Code: "+ statusCode);
				}

				else {
					System.out.println(url + " : Valid Link"+" Status Code: "+ statusCode);
				}

			}

			catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}

	}

}
