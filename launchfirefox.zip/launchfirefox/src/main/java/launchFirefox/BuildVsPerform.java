package launchFirefox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BuildVsPerform {

	public static void main(String[] args) throws Exception {

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://www.leafground.com/pages/Edit.html");
		
		Thread.sleep(3000);
		
		WebElement element = driver.findElement(By.xpath("//label[text()='Enter your email address']/following::input"));
		Actions action = new Actions(driver);
		action.click(element).sendKeys("Edited").perform();
		
	}

}
