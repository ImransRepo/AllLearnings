package launchFirefox;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CapabilitiesCheck {

	RemoteWebDriver driver;
	
	@Test
	public void checkCaps() {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://github.com/login");
		
		Capabilities caps = driver.getCapabilities();
		String browserName = caps.getBrowserName();
		System.out.println(browserName);
		
	}
	
}
