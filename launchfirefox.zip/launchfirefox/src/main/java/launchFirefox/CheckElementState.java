package launchFirefox;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CheckElementState {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("http://www.leafground.com/pages/Edit.html");
		
		WebElement element = driver.findElement(By.xpath("//label[text()='Confirm that edit field is disabled']/following::input"));
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		Boolean disable = (Boolean) js.executeScript("return arguments[0].hasAttribute(\"disabled\");",element);
		System.out.println(disable);

		
		
		
		
	}

}
