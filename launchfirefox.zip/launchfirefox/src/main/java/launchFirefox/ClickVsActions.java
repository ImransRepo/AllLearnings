package launchFirefox;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ClickVsActions {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		ChromeOptions co = new ChromeOptions();
		
		driver.manage().window().maximize();
		
		WebElement element = driver.findElementById("");
		element.click(); // Clicks the particular element
		
		Actions action = new Actions(driver);
		action.click(); // Click at the current mouse location
		action.click(element); // Clicks the particular element
//		action.keyDown(Keys.)
		
	}

}
