package launchFirefox;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DifferentClicks {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("http://www.leafground.com/");
		WebElement element1 = driver.findElement(By.xpath("//a[@href='pages/Button.html']"));
		element1.sendKeys(Keys.ENTER);
		System.out.println("Element Clicked Using Sendkeys");
		Thread.sleep(5000);
		
		WebElement element2 = driver.findElement(By.xpath("//button[text()='Go to Home Page']"));
		element2.click();
		System.out.println("Element Clicked Using WebElement.click();");
		Thread.sleep(5000);
		
		WebElement element3 = driver.findElement(By.xpath("//a[@href='pages/Button.html']"));
		Actions action = new Actions(driver);
		action.click(element3).perform();
		System.out.println("Element Clicked Using Actions class");
		Thread.sleep(5000);
		
		WebElement element4 = driver.findElement(By.xpath("//button[text()='Go to Home Page']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", element4);
		System.out.println("Element Clicked Using JSE");


	}

}
