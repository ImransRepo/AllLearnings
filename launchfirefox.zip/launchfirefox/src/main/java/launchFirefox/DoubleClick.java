package launchFirefox;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

/*import com.aventstack.extentreports.Status;

import xcentral.Helper;
*/
public class DoubleClick {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");

		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability("marionette", true);
		WebDriver driver = new FirefoxDriver(capabilities);
		
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
		WebElement uname = driver.findElement(By.id("txtUsername"));    //username
        uname.sendKeys("Admin");
         
        WebElement pwd = driver.findElement(By.name("txtPassword"));       //password
        pwd.sendKeys("admin123");
         
        WebElement login_button = driver.findElement(By.xpath("//input[@id='btnLogin']"));
        login_button.click();                          //loginbutton
        
        Thread.sleep(5000);
        
        WebElement admin = driver.findElement(By.id("menu_admin_viewAdminModule"));
        
        ((JavascriptExecutor)driver).
		executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);",admin);
        
        System.out.println("Double Click worked");
	}
	
	/*public static boolean jsdoubleclick(String elementPath, String label, String waittime) throws Exception {
		boolean flag =false;
		try {
			if(waitforelementclickable(elementPath, label, waittime)) {
				WebElement element = d.findElement(By.xpath(selector(elementPath)));
				JavascriptExecutor js = ((JavascriptExecutor) d);
				js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);",element);
				Helper.testlog("pass", label ,"Double Clicked", test);
				flag = true;
			}	
		}
		catch (Exception e) {
			test.addScreenCaptureFromBase64String(Helper.EncodeImage(d, reportScreenshotLocation+"/Screenshot.jpg"));
			test.log(Status.FAIL, e.getMessage());
		}
		return flag;
	}
	
	public static boolean jsmousehover(String elementPath, String label, String waittime) throws Exception {
		boolean flag =false;
		try {
			if(waitforelementclickable(elementPath, label, waittime)) {
				WebElement element = d.findElement(By.xpath(selector(elementPath)));
				JavascriptExecutor js = ((JavascriptExecutor) d);
				js.executeScript("if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}",element);
				Helper.testlog("pass", label ,"Double Clicked", test);
				flag = true;
			}	
		}
		catch (Exception e) {
			test.addScreenCaptureFromBase64String(Helper.EncodeImage(d, reportScreenshotLocation+"/Screenshot.jpg"));
			test.log(Status.FAIL, e.getMessage());
		}
		return flag;
	}*/

}
