package launchFirefox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.FindAll;

public class GitLogin {

	WebDriver driver;
	@FindBy(id = "login_field")
	public WebElement username;
	@FindBy(id = "password")
	public WebElement password;
	@FindBy(xpath = "//input[@value='Sign in']")
	public WebElement submit;
 
	public GitLogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBys({@FindBy(id = ""),@FindBy(xpath="")})
	WebElement user;  // Used to locate webelement with more than 1 criteria ; AND conditional relationship
	
	@FindAll({@FindBy(id = ""),@FindBy(xpath="")})
	WebElement pass; // Used to locate webelement with more than 1 criteria ; OR conditional relationship
	
}
