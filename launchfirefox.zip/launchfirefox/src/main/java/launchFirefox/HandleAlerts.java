package launchFirefox;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class HandleAlerts extends BasePage {

	@Test
	public static void alerts() throws InterruptedException, AWTException {
		
		
		driver.get("http://www.leafground.com/pages/Alert.html");
//		driver.findElement(By.cssSelector("button[onclick='confirmAlert()']")).click();;
		
		Thread.sleep(2000);
		

		
//		Alert alert ;
		
		/*driver.switchTo().alert().accept();

		Robot rbt = new Robot();
		rbt.keyPress(KeyEvent.VK_ENTER);
		rbt.keyRelease(KeyEvent.VK_ENTER);

		
		System.out.println("First Alert");
		
		
		
		driver.findElement(By.cssSelector("button[onclick='normalAlert()']")).click();;
		
		System.out.println("Second Alert");
		
		driver.navigate().refresh();
		
		System.out.println("Page Refreshed");*/
		
		Thread.sleep(5000);
		
		WebElement promptAlert = driver.findElement(By.xpath("//button[text()='Prompt Box']"));
		promptAlert.click();
		
		Thread.sleep(5000);
		
		driver.switchTo().alert().dismiss();
		
	}

}
