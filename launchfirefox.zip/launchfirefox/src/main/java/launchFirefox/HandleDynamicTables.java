package launchFirefox;

import java.text.NumberFormat;

import org.openqa.selenium.remote.LocalFileDetector;
import org.testng.annotations.Test;

public class HandleDynamicTables extends BasePage {
	
	@Test
	public void handletables() {
		
//		driver.setFileDetector(new LocalFileDetector());
		
		
	}

}
