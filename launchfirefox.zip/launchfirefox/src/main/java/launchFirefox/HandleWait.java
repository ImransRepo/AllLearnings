package launchFirefox;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HandleWait {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		WebElement element = driver.findElement(By.xpath("xpath"));
		WebDriverWait wait = new WebDriverWait(driver,20);
		
		try {
		
			wait.ignoring(NoSuchElementException.class)
			.pollingEvery(Duration.ofSeconds(5))
			.ignoring(StaleElementReferenceException.class)
			.until(ExpectedConditions.visibilityOf(element));
			
		}catch(Exception e) {
			
		}
		
		FluentWait<WebDriver> fwait = new FluentWait<WebDriver>(driver);
	
//		NotFoundException.class
	}

}
