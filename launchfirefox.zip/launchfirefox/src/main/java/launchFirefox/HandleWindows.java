package launchFirefox;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HandleWindows {
	
	static ChromeDriver driver;

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		/*String windowHandle = driver.getWindowHandle();
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> handles = new ArrayList<String>(windowHandles);
		System.out.println(handles);
		String child1 = handles.get(1);
		driver.switchTo().window(child1);
		Iterator<String> it = handles.iterator();
		while(it.hasNext()) {
		
			String child = it.next();
			driver.switchTo().window(child);
			
		}*/
		
		switchToParent();
		
	}
	
	static void switchToParent() {
		
		driver.get("http://www.leafground.com/");
		driver.findElement(By.xpath("//img[@alt='Windows']")).click();;
		
		String parent = driver.getWindowHandle();
		
		driver.findElement(By.xpath("//button[text()='Open Home Page']")).click();
		
		Set<String> windowHandles = driver.getWindowHandles();
		
		List<String> handles = new ArrayList<String>(windowHandles);
		
		for(String each: handles) {
			
			if(!each.equalsIgnoreCase(parent)) {
				
				driver.switchTo().window(each);
				System.out.println(driver.getTitle());
				driver.close();
			}
			
		}
		
		driver.switchTo().window(parent);
		
		driver.findElement(By.xpath("//button[text()='Open Multiple Windows']")).click();;
		
	}

}
