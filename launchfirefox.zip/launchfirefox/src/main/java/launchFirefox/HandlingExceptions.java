package launchFirefox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class HandlingExceptions extends BasePage {
	
		
	@Test
	public static void HandleStaleness() throws InterruptedException {
		
		driver.get("https://github.com/login");
		GitLogin he = new GitLogin(driver);
		he.username.sendKeys("amod");
		he.password.sendKeys("dsds");
		he.submit.click();
		Thread.sleep(5000);
		// Same element
		he.username.sendKeys("amod");
		he.password.sendKeys("dsds");
		he.submit.click();
		
		
	}

}
