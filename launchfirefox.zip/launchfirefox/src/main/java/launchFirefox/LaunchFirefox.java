package launchFirefox;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class LaunchFirefox {

	public static void main(String[] args) throws Exception {
		
		

		System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");

		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability("marionette", true);
		WebDriver driver = new FirefoxDriver(capabilities);

		
		  driver.get("http://vsi.nimble.tnq.co.in/");
		  
		  WebElement element = driver.findElement(By.xpath("//h1[text()='Nimble']"));
		  
		  Point point = element.getLocation();
			int xcord = point.getX();
			System.out.println("Position of the webelement from left side is "+xcord +" pixels");
			int ycord = point.getY();
			System.out.println("Position of the webelement from top side is "+ycord +" pixels");

		  
		 /* driver.findElement(By.xpath("//input[@id='username']")).sendKeys(
		  "automatenimble");
		  driver.findElement(By.xpath("//input[@id='password']")).sendKeys("nimble");
		  driver.findElement(By.xpath("//input[@name='signin']")).click();
		  
		  
		  
		  Thread.sleep(10000);
		  
		  driver.findElement(By.xpath("//span[text()='Modify Articles / Issues']")).
		  click();
		  
		  Thread.sleep(30000);
		  
		  driver.findElement(By.xpath("(//div[@class='x-grid-row-checker'])[1]")).click
		  ();
		  
		  Thread.sleep(10000);
		  
		  driver.findElement(By.xpath("(//span[text()='Push To Any'])[1]")).click();
		  
		  Thread.sleep(10000);
		  
		  WebElement element =
		  driver.findElement(By.xpath("(//div[text()='QCCORR-3'])[2]"));
		  
		  boolean displayed = element.isDisplayed();
		  
		  System.out.println("Is Element displayed: "+ displayed);*/
		  
		  /*String mouseOverScript =
		  "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}"
		  ; ((JavascriptExecutor) driver).executeScript(mouseOverScript,element);
		  
		  ((JavascriptExecutor) driver).executeScript("arguments[0].dblclick();",
		  element);*/
		  
		 

		/*Trial 1*/
		
		/*driver.get("http://demo.guru99.com/test/simple_context_menu.html");

		Thread.sleep(30000);

		WebElement element = driver.findElement(By.xpath("//button[text()='Double-Click Me To See Alert']"));
*/
//		new Actions(driver).moveToElement(element).build().perform();

		
//		String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
		
		/*((JavascriptExecutor) driver).executeScript(mouseOverScript, element);
		
		System.out.println("MO completed");

		((JavascriptExecutor) driver).executeScript("arguments[0].dblclick();", element);*/
		
		/*Trial 2*/
		
		/*((JavascriptExecutor)driver).
		executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);",element);
*/
	}

}
