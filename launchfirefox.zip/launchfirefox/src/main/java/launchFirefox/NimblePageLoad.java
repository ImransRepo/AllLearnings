package launchFirefox;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NimblePageLoad {
	
	public static WebDriver driver;
	public static JavascriptExecutor js ;
	public static WebDriverWait wd;

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
//		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.geeksforgeeks.org/how-to-show-page-loading-div-until-the-page-has-finished-loading/");
		
		
		wd = new WebDriverWait(driver, 120);
		
//		wd.until(ExpectedConditions.jsReturnsValue("return document.readyState"));
		
		Object executeScript = js.executeScript("return document.readyState");
		
		String state = executeScript.toString();
		
		System.out.println("Page state is "+ state);
		
		
		
	}

}
