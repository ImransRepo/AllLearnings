package launchFirefox;

import java.io.File;
import java.io.IOException;

import org.apache.commons.compress.archivers.dump.DumpArchiveEntry.TYPE;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;


public class Reports {

	/*ExtentSparkReporter reporter = new ExtentSparkReporter(System.getProperty("user.dir")+"SampleReport.html");
	ExtentReports report = reporter.*/ 
	
	static ExtentSparkReporter reporter;
	static ExtentReports reports;
	static ExtentTest test;
	static WebDriver driver;
//	static ExtentHtmlReporter htmlreporter;
	
	@BeforeSuite
	public void setUp() {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("http://www.leafground.com/");
		
		reporter = new ExtentSparkReporter(System.getProperty("user.dir")+"Sample.html");
		reports = new ExtentReports();
		reports.attachReporter(reporter);
		
		test = reports.createTest("Leaf Ground Test");
		
		
	}
	
	@Test
	public void verifyEditPage() throws IOException {
				
		WebElement windows = driver.findElement(By.xpath("//img[@alt='Windows']"));
		windows.click();
		String title = driver.getTitle();
		System.out.println(title);
		String expectedTitle = "TestLeaf - Interct with Windows";
		if(title.equalsIgnoreCase(expectedTitle)) {
			
			test.log(Status.PASS, "Title Matching");
		}
		
		else {
			
//			test.log(Status.FAIL,  test.addScreenCaptureFromPath(capture(null)));
		}
	}
	
	@AfterSuite
	public void afterTest() {
		
		reports.flush();
	}
	
	String capture(WebDriver driver) throws IOException {
		
		File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Dest = new File(System.getProperty("user.dir")+System.currentTimeMillis()+".png");
		String errfilePath = Dest.getAbsolutePath();
		
		FileUtils.copyFile(srcFile, Dest);
		
		return errfilePath;
		
	}

}
