package launchFirefox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class RightClick extends BasePage {

	@Test
	public void rightClick() throws InterruptedException
	{
		
		driver.get("http://demo.guru99.com/test/simple_context_menu.html");
		
		WebElement link =driver.findElement(By.xpath("//button[text()='Double-Click Me To See Alert']"));
		Actions action = new Actions(driver);
	
		
		Thread.sleep(3000);
		action.contextClick(link).build().perform();
		
	}
}
