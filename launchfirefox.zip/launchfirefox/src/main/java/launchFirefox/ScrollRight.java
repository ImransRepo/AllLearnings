package launchFirefox;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ScrollRight {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
//		driver.get("https://demoqa.com/webtables");
		driver.get("https://trello.com/b/LakLkQBW/jsfiddle-roadmap");
		
		
		//http://ressio.github.io/lazy-load-xt/demo/horizontal.htm
		
		Thread.sleep(10000);
		
		/*using JSexecutor*/
		
//		WebElement scrollArea = driver.findElement(By.className("wrapper"));
		
		/*WebElement scrollArea = driver.findElement(By.xpath("//div[@role='grid']"));
		
		JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        javascriptExecutor.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);*/
        
        /*using Sendkeys*/
		
		/*WebElement scrollArea = driver.findElement(By.id("board"));
		
		Actions action = new Actions(driver);

		for (int i = 0; i < 5; i++) {
		    action.moveToElement(scrollArea).sendKeys(Keys.RIGHT).build().perform();
		}*/
		
		/*Vertical Scroll until element is visible*/
				
		WebElement element = driver.findElement(By.xpath("//span[text()='Ability to tag fiddles']"));
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", element);
		
        
        
		
	}

}
