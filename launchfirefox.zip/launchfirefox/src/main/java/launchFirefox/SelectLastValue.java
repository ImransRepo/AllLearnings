package launchFirefox;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SelectLastValue {

	public static void main(String[] args) throws InterruptedException {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("http://www.leafground.com/pages/Dropdown.html");
		
		Thread.sleep(3000);
		
		WebElement dropdown1 = driver.findElement(By.id("dropdown1"));
		
		/* Select Last Value from Dropdown using getOptions/Select class */
		
		/*Select select = new Select(dropdown1);
		
		List<WebElement> options = select.getOptions();	
		
		int totalOptions = options.size();
		
		String lastOption = options.get(totalOptions-1).getText();
		System.out.println("Last Option is: "+ lastOption);
		
		select.selectByIndex(totalOptions-1);*/
		
		
		/* Select Last Value from Dropdown without getOptions/Select class */
		
		dropdown1.click();
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//select[@id='dropdown1']/option[last()]")).click();;
		
		Thread.sleep(2000);
		
		driver.findElementByXPath("//select[@class='dropdown']").click();
		
		
	}
	
	

}
