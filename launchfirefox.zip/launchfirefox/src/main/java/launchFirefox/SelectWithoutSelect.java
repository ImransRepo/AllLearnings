package launchFirefox;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SelectWithoutSelect {

	public static WebDriver driver;
	public static WebDriverWait wait;
//	public static String option = "Appium";

	@BeforeTest
	public static void loadURL() {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("http://www.leafground.com/pages/Dropdown.html");

		
	}

	@Test(enabled=false)
	public static void selectWithoutSelect() {

		WebElement dropdown1 = driver.findElement(By.id("dropdown1"));
		dropdown1.click();

		List<WebElement> options1 = driver.findElements(By.xpath("//select[@id='dropdown1']/option"));

		int totaloptions = options1.size();
		
		List<String> list2 = new ArrayList<String>();
		
		for (int i = 0; i < totaloptions; i++) {
			
			String text = options1.get(i).getText();
			
			list2.add(text);
			
		}
		
		Collections.sort(list2);
		
		System.out.println(list2.get(0));
		System.out.println(list2.get(totaloptions-1));
		

		String option = "Selenium";

		for (int i = 0; i < totaloptions; i++) {

			if (options1.get(i).getText().equalsIgnoreCase(option)) {

				driver.findElement(By.xpath("//select[@id='dropdown1']/option[text()='" + option + "']")).click();
				break;
			}
		}

		dropdown1.click();

	}
	
	@Test(enabled=true)
	public static void selectWithSelect() {
		
		WebElement dropdown1 = driver.findElement(By.id("dropdown1"));
		Select select = new Select(dropdown1);
		
//		select.selectByIndex(4);
//		select.selectByValue("4");
		select.selectByVisibleText("Loadrunner");
		
		assertEquals("Loadrunner",select.getFirstSelectedOption().getText());
		
				
		
	}

}
