package launchFirefox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.AbstractWebDriverEventListener;

public class SeleniumListeners extends AbstractWebDriverEventListener {
	
	public void beforeAlertAccept(WebDriver driver) {
	    // Do nothing.
	  }

}
