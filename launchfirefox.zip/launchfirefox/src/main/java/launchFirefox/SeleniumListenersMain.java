package launchFirefox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

public class SeleniumListenersMain extends SeleniumListeners {
	
	WebDriver driver;
	EventFiringWebDriver eventHandler = new EventFiringWebDriver(driver);
	SeleniumListeners eCapture = new SeleniumListeners();
//	eventHandler.register(eCapture);

}
