package launchFirefox;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SortDropdown {

	public static void main(String[] args) throws InterruptedException {

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://www.leafground.com/pages/Dropdown.html");
		
		Thread.sleep(3000);
		
		WebElement dropdown1 = driver.findElement(By.id("dropdown1"));
		Select select = new Select(dropdown1);
		
		List<WebElement> options = select.getOptions();
		
			
		List<String> newlist = new ArrayList<String>();
		
		for (WebElement each: options) {
			
			newlist.add(each.getText());
		}
		
		System.out.println("All Options Before Sorted: "+ newlist);
		
		Collections.sort(newlist);
		
		System.out.println("All Options after sorting in Ascending order: "+ newlist);
		
		Collections.reverse(newlist);
		
		System.out.println("All Options after sorting in Descending order: "+ newlist);
		
		
		
		
		
	}

}
