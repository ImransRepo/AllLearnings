package launchFirefox;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortValuesFromList {
	
	public static void main(String[] args) {
		
		
		ArrayList<Integer> list1 = new ArrayList<Integer>();
		list1.add(10);
		list1.add(5);
		list1.add(7);
		list1.add(25);
		list1.add(-25);
		
		int size = list1.size();
		
		
		Collections.sort(list1,Collections.reverseOrder());
		
		System.out.println("Max : "+list1.get(size-1));
		System.out.println("Min : "+list1.get(0));
		
		
		
		
		
		
	}

}
