package launchFirefox;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwitchTabs {
	
	public static ArrayList<String> handles;

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://10.0.5.128:6062/S&T/app.html");

		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("automatenimble");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("nimble");
		driver.findElement(By.xpath("//input[@name='signin']")).click();
		
		Thread.sleep(10000);
		
		driver.findElement(By.xpath("//span[text()='Reports']")).click();
		
		driver.findElement(By.xpath("//span[text()='Productivity']")).click();
		
		driver.findElement(By.xpath("//input[@name='customers']//following::div[1]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//li[text()='S&T']")).click();
		driver.findElement(By.xpath("//span[text()='Submit']")).click();
		
		handles = new ArrayList<String>(driver.getWindowHandles());
		
		for (String string : handles) {
			System.out.println("Window handles in home tab are: "+ string);
		}
		
		driver.switchTo().window(handles.get(1));
		
		
		
		
		driver.findElement(By.xpath("//th[text()='Non Productivity Activities']//following::a[1]")).click();
		
		ArrayList<String> handles2 = new ArrayList<String>(driver.getWindowHandles());
		
		
		for (String string : handles2) {
			System.out.println("Window handles in new tab are: "+ string);
		}
				
		/*driver.close();
		
		driver.switchTo().window(handles.get(0));
		
		driver.findElement(By.xpath("//span[text()='Productivity User']")).click();
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("(//input[@name='teamGroup']//following::div[1])[last()]")).click();
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//li[text()='Le Mans']")).click();
		
		driver.findElement(By.xpath("(//span[text()='Submit'])[last()]")).click();
		
		handles = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(handles.get(1));
		driver.findElement(By.xpath("//th[text()='Non Productivity Activities']//following::a[1]")).click();*/
		
		
		
	}

}
