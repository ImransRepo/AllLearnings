package launchFirefox;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestNG {
	
	
	/*@BeforeSuite
	void laodUrl() {
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.leafground.com/pages/Edit.html");
	}*/
	
	@Test(priority=0)
	void Test1() {
		System.out.println("Test 1");
	}
	
	@Test(priority=-11)
	void Test2() {
		System.out.println("Test 2");
	}
	
	@Test(priority=1)
	void Test3() {
		System.out.println("Test 3");
	}
	
	@Test(priority=-1)
	void Test4() {
		System.out.println("Test 4");
	}

}
