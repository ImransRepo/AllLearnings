package launchFirefox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

@Listeners(launchFirefox.TestNGListeners.class)
public class TestNGMain {
	
	WebDriver driver;
	
	@BeforeSuite
	public void setUp() {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
	}
	
	@Test(priority=-5, retryAnalyzer=launchFirefox.RetryAnalyzer.class)
	public void loadUrl() {
		
		driver.get("http://www.leafground.com/");
		String actualTitle = driver.getTitle();
//		System.out.println(actualTitle);
		String expectedTitle = "TestLeaf - Selenium Playground";
		Assert.assertEquals(actualTitle,expectedTitle);
	}
	
	@Test(retryAnalyzer=launchFirefox.RetryAnalyzer.class)
	public void failTest() {
		
		Assert.assertTrue(false);
	}

}
