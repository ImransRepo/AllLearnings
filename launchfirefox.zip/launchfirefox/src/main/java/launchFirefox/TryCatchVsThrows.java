package launchFirefox;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class TryCatchVsThrows {

	public static void main(String[] args) throws FileNotFoundException {

		method2();
		method1();
		
		
	}
	
	static void method1 () throws FileNotFoundException {
		
		FileReader reader = new FileReader(new File(""));
		System.out.println("File Read");
		
	}
	
	static void method2() {
		
		try {
			Thread.sleep(5000);
			System.out.println("Thread.Sleep works");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
