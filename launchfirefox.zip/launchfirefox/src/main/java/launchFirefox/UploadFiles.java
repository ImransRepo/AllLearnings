package launchFirefox;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class UploadFiles extends BasePage {
	
	public static String path ="C:\\Users\\TNQ\\Desktop\\Sample.jpg";
	public static String url = "https://www.naukri.com/";


	@Test
	public static void lamdaTest() throws Exception {
		
		driver.get(url);
		
		Thread.sleep(2000);

		/* Using Sendkeys */
		
		/*WebElement addFile = driver.findElement(By.xpath(".//input[@type='file']"));
		addFile.sendKeys(path);
		driver.findElement(By.xpath(".//span[text()='Start upload']")).click();*/
		
		/*For Naukri*/
		
		WebElement addFile = driver.findElement(By.xpath("//label[@for='file_upload']"));
		addFile.click();
		
		Thread.sleep(5000);
		
//		addFile.click();
		
		
//		UploadFiles.uploadUsingRobot();
	

	}

	public static void uploadUsingRobot() throws AWTException {
		
		/*Using Robot Class*/
		
		StringSelection string = new StringSelection(path);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(string, null);
		
		Robot robot = new Robot();
		
		/*robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);*/
		robot.delay(200);
		
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.delay(2000);
		
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);		
		
	}
	
	

}
