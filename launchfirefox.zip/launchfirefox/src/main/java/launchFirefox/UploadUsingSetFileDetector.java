package launchFirefox;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class UploadUsingSetFileDetector extends BasePage {

	public static String path = "C:\\Users\\TNQ\\Desktop\\Sample.jpg";
	public static String url = "https://www.naukri.com/";

	/* Using setFileDetector - Used to upload to Remote browsers from local */

	@Test
	public static void usingSetFileDetector() throws MalformedURLException {

		/*driver = new RemoteWebDriver(new URL(url), options);
		driver.setFileDetector(new LocalFileDetector());

		WebElement addFile = driver.findElement(By.xpath(".//input[@type='file']"));
		addFile.sendKeys(path);
		driver.findElement(By.xpath(".//span[text()='Start upload']")).click();*/

	}

}
