package launchFirefox;

import org.testng.annotations.Test;

public class WindowsAuth extends BasePage {
	
	@Test
	public static void windowsauthentication() {
		
		driver.get("https://admin:admin@the-internet.herokuapp.com/basic_auth");
	}

}
