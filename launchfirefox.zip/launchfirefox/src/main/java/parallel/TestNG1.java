package parallel;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

@Test
public class TestNG1 {

	@BeforeSuite
	public void method1() {
		System.out.println("Before Suite Class 1 - Method 1");
		}
	public void method2() {
		System.out.println("Class 1 - Method 2");
		}
	
	@AfterSuite
	public void method3() {
		System.out.println("After Suite Class 1 - Method 3");
		}
	
}
