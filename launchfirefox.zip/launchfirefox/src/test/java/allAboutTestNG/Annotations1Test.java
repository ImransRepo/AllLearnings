package allAboutTestNG;

import org.testng.annotations.Test;

public class Annotations1Test {

  @Test
  public void test1Test() {
    throw new RuntimeException("Test not implemented");
  }
}
