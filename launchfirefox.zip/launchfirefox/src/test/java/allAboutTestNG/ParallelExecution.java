package allAboutTestNG;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ParallelExecution {
	
	public static WebDriver driver;
	
	
	@Test
	public void method1() {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://demoqa.com/buttons");
		WebElement findElement = driver.findElement(By.xpath("//button[text()='Click Me']"));
		String cssValue = findElement.getCssValue("background-color");
		System.out.println(cssValue);
			
	}
	
	
	

}
