package org.nimble.launchfirefox;

public class Intersection {

	public static void main(String[] args) {

		int[] drawNumbers = {12, 45, 23, 31, 54, 63, 72, 23};
		int[] playedNumbers = {20, 44, 31, 64, 23, 84, 57, 10};
		
		for(int i=0; i<drawNumbers.length; i++) {
			for(int j=0; j<playedNumbers.length; j++) {
				
				if(drawNumbers[i] == playedNumbers[j]) {
					
					System.out.println(drawNumbers[i]);
					
				}
				
			}
		}
		
	}

}
