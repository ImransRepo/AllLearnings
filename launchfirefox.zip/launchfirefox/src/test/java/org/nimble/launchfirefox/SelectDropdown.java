package org.nimble.launchfirefox;

import java.util.Map;

import org.apache.commons.math3.util.OpenIntToDoubleHashMap.Iterator;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

public class SelectDropdown {

	public static void main(String[] args) {

	/*	WebElement = dropdown  = driver.findElement(By.xpath(""));
		Select select = new Select(drropdown);
		
		List<WebElement> alloptions = select.getOptions();
		
		Iterator it = alloptions.iterator();
		
		while(it.hasNext()) {
			
			it.next().getText();
			
			
		}
		
		Map<String,Integer> map = new HashMap<String,Integer>() ;
		
		
		for(String each: map) {
			
			if(each.containsKey()) {
				
				map.put(key, each.get(key)+1);
			}
			
			else {
				
				map.put(key, 1);
			}
		}
		
		System.out.println(map);
		
		for(Entry<String,Integer> each: map.entrySet() ) {
			
			if(each.getValue()>1) {
				
				System.out.println(each.getKey());
			}
		}*/
		
		
		
		
		
	}

}
